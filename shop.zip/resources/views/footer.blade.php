
<div id="footer" class="color-div">
	<div class="container">
		<div class="row">
		<div class="col-sm-2">
				<div class="widget">
					<h4 class="widget-title"></h4>
					<div>
						<ul>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="widget">
					<h4 class="widget-title">Why Us?</h4>
					<div>
						<ul>
							<li><a href="{{route('trang-chu')}}"><i class="fa fa-chevron-right"></i> TNT Pizza</a></li>
							<li><a href="{{route('trang-chu')}}"><i class="fa fa-chevron-right"></i> Our Staff</a></li>
							<li><a href="{{route('trang-chu')}}"><i class="fa fa-chevron-right"></i> Restaurant Amenities</a></li>
							<li><a href="{{route('trang-chu')}}"><i class="fa fa-chevron-right"></i> Food Resources</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="widget">
					<h4 class="widget-title"></h4>
					<div>
						<ul>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-sm-2">
				<div class="widget">
					<h4 class="widget-title"></h4>
					<div>
						<ul>
						</ul>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="col-sm-10">
				<div class="widget">
					<h4 class="widget-title">Contact Us</h4>
					<div>
						<div class="contact-info">
							<i class="fa fa-map-marker"></i>
							<p>19 Nguyễn Hữu Thọ, Phường Tân Phong, Quận 7</p>
							<p>Phone: 01234567899</p>
						</div>
					</div>
				</div>
				</div>
			</div>

		</div> <!-- .row -->
	</div> <!-- .container -->
</div> <!-- #footer -->
<div class="copyright">
	<div class="container">
		<p class="pull-left">(&copy;)TNT PIZZA VIETNAM 2020 </p>
		<p class="pull-right">MADE BY TRAN PHAM ANH TUAN & TO QUOC THANG</p>
		<div class="clearfix"></div>
	</div> <!-- .container -->
</div> <!-- .copyright -->