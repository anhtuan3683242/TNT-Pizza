
<?php $__env->startSection('content'); ?>
<div class="container">
		<div id="content">
			<div class="table-responsive">
				<!-- Shop Products Table  echo //(\App\products::find($chitietmon['MaSp'])->TenSp)->get() // -->
				<table class="shop_table beta-shopping-cart-table" cellspacing="0">
					<thead>
						<tr>
							<th class="product-name"></th>
							<th class="product-quantity">Tên món</th>
							<th class="product-quantity">Số lượng</th>
						</tr>
					</thead>
					<tbody>
                        <?php $__currentLoopData = $chitiet_donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chitietmon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="cart_item">	
							<td class="product-name">
								<div class="media">
								<a class="pull-left" ><img class="pull-left" src="source/image/product/<?php echo e($chitietmon->Hinh); ?>" alt="" width="140px" height="100px"></a>
								<td>
                                    <p style=" padding-top: 35px;"><?php echo e($chitietmon->TenSp); ?></p>
									</td>
								</div>
							</td>


							<td class="product-quantity" width = " 70">
                                <p>Số lượng: <?php echo e($chitietmon->quantity); ?> </p>
							</td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>

				</table>
				<!-- End of Shop Table Products -->
			</div>
			<a class="back-btn" href="<?php echo e(route('nha-bep')); ?>" ><i class="fa fa-chevron-left"></i> Trở lại</i></a>
			<!-- End of Cart Collaterals -->
		<div class="clearfix"></div>
	</div> <!-- #content -->
</div> <!-- .container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/shop/resources/views/page/checkdon.blade.php ENDPATH**/ ?>