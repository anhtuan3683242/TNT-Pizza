
<?php $__env->startSection('content'); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Đăng nhập</h6>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	
	<div class="container">
		<div id="content">
			
			<form action="<?php echo e(route('login')); ?>" method="post" class="beta-form-checkout">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<div class="row">
					<div class="col-sm-3"></div>
					<?php if(Session::has('flag')): ?>
						<div class="alert alert-<?php echo e(Session::get('flag')); ?>"><?php echo e(Session::get('message')); ?></div>
					<?php endif; ?>
				</div>
					<div class="col-sm-6">

						<div class="form-block">
							<label for="email">Email address*</label>
							<input type="email" name="email" style="border: 1px solid black;" required>
						</div>
						<div class="form-block">
							<label for="phone">Password*</label>
							<input type="password" name="password" style="border: 1px solid black;" required>
						</div>
						<div class="form-block">
							<button type="submit" class="btn btn-color">Đăng nhập</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				
			</form>
		</div> <!-- #content -->
	</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/dangnhap.blade.php ENDPATH**/ ?>