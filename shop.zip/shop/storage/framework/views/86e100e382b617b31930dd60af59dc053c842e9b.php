
<?php $__env->startSection('content'); ?>
<style>
#customers {
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
<div class="inner-header">
    <div class="container">
        <div class="pull-left">
            <h6 class="inner-title">check bếp</h6>
        </div>
        <div class="pull-right">
            <div class="beta-breadcrumb">
                <a href="<?php echo e(route('trang-chu')); ?>">Trang chủ</a> / <span>check bếp</span>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
    
<div class="container">
    <div id="content">
    <div class="row" style="color:red; text-align:center;"><strong><?php if(Session::has('thongbao')): ?><?php echo e(Session::get('thongbao')); ?><?php endif; ?></strong></div>
        <table id="customers">
        <tr>
            <th>ID</th>
            <th>thông tin đơn:</th>
            <th>Finish</th>
        </tr>
        <?php $__currentLoopData = $donhang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        
            <td><?php echo e($don->MaDonDatHang); ?></td>
            <td><a href="<?php echo e(route('check',$don->MaDonDatHang)); ?>"><i class="fa fa-thumb-tack"></i> Thông tin</a></td>
            <td><a href="xoa/<?php echo e($don['MaDonDatHang']); ?>"> Xóa</a></td>
        
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </div> <!-- #content -->
</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\shop\resources\views/page/nhabep.blade.php ENDPATH**/ ?>