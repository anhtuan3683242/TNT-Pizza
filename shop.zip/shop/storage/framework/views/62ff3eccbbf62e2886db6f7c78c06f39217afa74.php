
<?php $__env->startSection('content'); ?>
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Sản phẩm <?php echo e($ten_loai->TenLoai); ?></h6>
			</div>
			<div class="pull-right">
				<div class="beta-breadcrumb font-large">
					<a href="<?php echo e(route('trang-chu')); ?>">Home</a> / <span>Sản phẩm <?php echo e($ten_loai->TenLoai); ?></span>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
</div>
<div class="container">
		<div id="content" class="space-top-none">
			<div class="main-content">
				<div class="space60">&nbsp;</div>
				<div class="row">
					<div class="col-sm-3">
						<ul class="aside-menu">
						<?php $__currentLoopData = $loai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><a href="<?php echo e(route('loaisp',$l->MaLoaiSP)); ?>"><?php echo e($l->TenLoai); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</div>
					<div class="col-sm-9">
						<div class="beta-products-list">
							<h4>Sản Phẩm mới</h4>
							<div class="beta-products-details">
								<p class="pull-left">Tìm thấy <?php echo e(count($sp_theoloai)); ?> sản phẩm</p>
								<div class="clearfix"></div>
							</div>

						<div class="row">
						<?php $__currentLoopData = $sp_theoloai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-sm-4">
								<div class="single-item">
									<div class="single-item-header">
										<a href="<?php echo e(route('chitietsp',$sp->id)); ?>"><img src="source/image/product/<?php echo e($sp->Hinh); ?>" alt="" height="250px"></a>
									</div>
									<div class="single-item-body">
										<p class="single-item-title"><?php echo e($sp->TenSp); ?></p>
										<p class="single-item-price" style="font-size:18px">
											<span><?php echo e(number_format($sp->GiaSp)); ?> đồng</span>
											<div class="space10">&nbsp;</div>
										</p>
									</div>
									<div class="single-item-caption">
										<a class="add-to-cart pull-left" href="<?php echo e(route('themgiohang',$sp->id)); ?>"><i class="fa fa-shopping-cart"></i></a>
										<a class="beta-btn primary" style="  margin-left:4px;" href="<?php echo e(route('chitietsp',$sp->id)); ?>">Details <i class="fa fa-chevron-right"></i></a>
										<div class="clearfix"></div>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div> <!-- .beta-products-list -->

					<div class="space50">&nbsp;</div>

					
						<div class="space40">&nbsp;</div>
						
					</div> <!-- .beta-products-list -->
				</div>
			</div> <!-- end section with sidebar and main content -->


		</div> <!-- .main-content -->
	</div> <!-- #content -->
</div> <!-- .container -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/page/loaisp.blade.php ENDPATH**/ ?>