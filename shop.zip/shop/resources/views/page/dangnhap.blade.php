@extends('master')
@section('content')
<div class="inner-header">
		<div class="container">
			<div class="pull-left">
				<h6 class="inner-title">Đăng nhập</h6>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	
	<div class="container">
		<div id="content">
			
			<form action="{{route('login')}}" method="post" class="beta-form-checkout">
			<input type="hidden" name="_token" value="{{csrf_token()}}">
				<div class="row">
					<div class="col-sm-3"></div>
					@if(Session::has('flag'))
						<div class="alert alert-{{Session::get('flag')}}">{{Session::get('message')}}</div>
					@endif
				</div>
					<div class="col-sm-6">

						<div class="form-block">
							<label for="email">Email address*</label>
							<input type="email" name="email" style="border: 1px solid black;" required>
						</div>
						<div class="form-block">
							<label for="phone">Password*</label>
							<input type="password" name="password" style="border: 1px solid black;" required>
						</div>
						<div class="form-block">
							<button type="submit" class="btn btn-color">Đăng nhập</button>
						</div>
					</div>
					<div class="col-sm-3"></div>
				
			</form>
		</div> <!-- #content -->
	</div> <!-- .container -->
@endsection