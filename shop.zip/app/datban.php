<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class datban extends Model
{
    protected $table = "datban";
}
