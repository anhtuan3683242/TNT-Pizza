<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tinhtrang extends Model
{
    protected $table = "tinhtrang";
}
